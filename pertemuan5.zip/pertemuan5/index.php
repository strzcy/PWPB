<?php
// Menyertakan file koneksi.php
require 'koneksi.php';
// Jika skrip berhasil sampai sini tanpa error, artinya koneksi berhasil.
// Kita tampilkan pesan sukses.
echo "Selamat, koneksi ke database berhasil!";
?>